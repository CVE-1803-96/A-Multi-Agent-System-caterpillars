import numpy as np
import random
from typing import Dict, List, Tuple, Any
from .base import BaseOptimizationAlgorithm

class ProcessionaryCaterpillar(BaseOptimizationAlgorithm):
    """Processionary Caterpillar algorithm implementation."""
    
    def __init__(self, population_size: int, environment, following_distance: float = 1.0,
                 leader_influence: float = 0.7, pheromone_strength: float = 1.0,
                 formation_flexibility: float = 0.5, **kwargs):
        
        self.following_distance = following_distance
        self.leader_influence = leader_influence
        self.pheromone_strength = pheromone_strength
        self.formation_flexibility = formation_flexibility
        
        # Trail management
        self.pheromone_trail = []
        self.trail_decay_rate = 0.05
        
        super().__init__(population_size, environment, **kwargs)
    
    def initialize_population(self):
        """Initialize caterpillar population in linear formation."""
        self.agents = []
        
        # Start position for the procession
        start_x = self.environment.width * 0.1
        start_y = self.environment.height * 0.5
        
        for i in range(self.population_size):
            # Create linear formation with the first caterpillar as leader
            position_x = start_x - (i * self.following_distance)
            position_y = start_y + random.uniform(-0.5, 0.5)  # Small variation
            
            caterpillar = {
                'id': i,
                'position': [position_x, position_y],
                'velocity': [0.0, 0.0],
                'is_leader': i == 0,
                'leader_id': 0 if i > 0 else None,
                'followers': [] if i == 0 else None,
                'fitness': float('inf'),
                'base_sensing_range': 3.0,
                'sensing_range': 3.0,
                'trail_strength': 1.0,
                'formation_position': i,
                'target_following_distance': self.following_distance
            }
            
            # Set up follower relationships
            if i > 0:
                caterpillar['leader_id'] = i - 1
            
            self.agents.append(caterpillar)
        
        # Set up leader's follower list
        for i, caterpillar in enumerate(self.agents):
            if caterpillar['is_leader']:
                caterpillar['followers'] = [j for j in range(1, self.population_size)]
    
    def update_agents(self):
        """Update caterpillar positions using leader-follower dynamics."""
        # Update trail decay
        self.decay_pheromone_trail()
        
        # Update leader first
        leader = self.agents[0]
        self.update_leader(leader)
        
        # Update followers in order
        for i in range(1, len(self.agents)):
            self.update_follower(self.agents[i])
        
        # Deposit pheromone trails
        for caterpillar in self.agents:
            self.deposit_trail_pheromone(caterpillar)
    
    def update_leader(self, leader):
        """Update the leader caterpillar towards the target."""
        current_pos = np.array(leader['position'])
        target_pos = np.array(self.environment.target_position)
        
        # Calculate direction to target
        direction = target_pos - current_pos
        distance_to_target = np.linalg.norm(direction)
        
        if distance_to_target > 0:
            direction = direction / distance_to_target
        
        # Add some randomness for exploration
        exploration_factor = 0.2
        random_direction = np.random.normal(0, exploration_factor, 2)
        
        # Combine target-seeking with exploration
        final_direction = (direction * (1 - exploration_factor) + 
                         random_direction * exploration_factor)
        
        # Calculate velocity
        base_speed = 1.0
        velocity = final_direction * base_speed
        
        # Apply environmental effects
        velocity = self.apply_environmental_effects_to_velocity(velocity, leader)
        
        # Update position
        leader['velocity'] = velocity.tolist()
        new_position = current_pos + velocity
        
        # Keep within bounds
        new_position[0] = np.clip(new_position[0], 0, self.environment.width)
        new_position[1] = np.clip(new_position[1], 0, self.environment.height)
        
        leader['position'] = new_position.tolist()
    
    def update_follower(self, follower):
        """Update a follower caterpillar to follow its leader."""
        leader_id = follower['leader_id']
        if leader_id is None or leader_id >= len(self.agents):
            return
        
        leader = self.agents[leader_id]
        current_pos = np.array(follower['position'])
        leader_pos = np.array(leader['position'])
        
        # Calculate following behavior
        direction_to_leader = leader_pos - current_pos
        distance_to_leader = np.linalg.norm(direction_to_leader)
        
        if distance_to_leader > 0:
            direction_to_leader = direction_to_leader / distance_to_leader
        
        # Desired following distance with some flexibility
        desired_distance = (follower['target_following_distance'] + 
                          random.uniform(-self.formation_flexibility, self.formation_flexibility))
        
        # Calculate target position behind leader
        if distance_to_leader > desired_distance:
            # Too far from leader, move closer
            target_pos = leader_pos - direction_to_leader * desired_distance
            direction = target_pos - current_pos
            distance_to_target = np.linalg.norm(direction)
            
            if distance_to_target > 0:
                direction = direction / distance_to_target
            
            # Movement speed based on distance
            speed = float(min(1.5, distance_to_target * 0.5))
            velocity = direction * speed
            
        elif distance_to_leader < desired_distance * 0.7:
            # Too close to leader, slow down or stop
            velocity = np.array([0.0, 0.0])
        else:
            # Good distance, follow leader's direction
            leader_velocity = np.array(leader.get('velocity', [0, 0]))
            velocity = leader_velocity * 0.8  # Slightly slower than leader
        
        # Add pheromone trail following behavior
        trail_influence = self.follow_pheromone_trail(current_pos)
        velocity += trail_influence * self.pheromone_strength * 0.3
        
        # Apply environmental effects
        velocity = self.apply_environmental_effects_to_velocity(velocity, follower)
        
        # Update position
        follower['velocity'] = velocity.tolist()
        new_position = current_pos + velocity
        
        # Keep within bounds
        new_position[0] = np.clip(new_position[0], 0, self.environment.width)
        new_position[1] = np.clip(new_position[1], 0, self.environment.height)
        
        follower['position'] = new_position.tolist()
    
    def follow_pheromone_trail(self, position: np.ndarray) -> np.ndarray:
        """Calculate influence from pheromone trail."""
        if not self.pheromone_trail:
            return np.array([0.0, 0.0])
        
        influence = np.array([0.0, 0.0])
        total_weight = 0.0
        
        for trail_point in self.pheromone_trail:
            trail_pos = np.array(trail_point['position'])
            distance = np.linalg.norm(position - trail_pos)
            
            if distance < 3.0:  # Within sensing range
                weight = trail_point['strength'] / (distance + 0.1)
                direction = trail_pos - position
                if np.linalg.norm(direction) > 0:
                    direction = direction / np.linalg.norm(direction)
                
                influence += direction * weight
                total_weight += weight
        
        if total_weight > 0:
            influence = influence / total_weight
        
        return influence
    
    def deposit_trail_pheromone(self, caterpillar):
        """Deposit pheromone trail for followers to follow."""
        trail_point = {
            'position': caterpillar['position'].copy(),
            'strength': caterpillar['trail_strength'],
            'depositor_id': caterpillar['id'],
            'age': 0
        }
        
        self.pheromone_trail.append(trail_point)
        
        # Limit trail length
        max_trail_length = self.population_size * 10
        if len(self.pheromone_trail) > max_trail_length:
            self.pheromone_trail = self.pheromone_trail[-max_trail_length:]
    
    def decay_pheromone_trail(self):
        """Apply decay to pheromone trail."""
        for trail_point in self.pheromone_trail:
            trail_point['age'] += 1
            trail_point['strength'] *= (1 - self.trail_decay_rate)
        
        # Remove very weak or old trail points
        self.pheromone_trail = [
            point for point in self.pheromone_trail
            if point['strength'] > 0.1 and point['age'] < 100
        ]
    
    def apply_environmental_effects_to_velocity(self, velocity: np.ndarray, caterpillar) -> np.ndarray:
        """Apply environmental effects to velocity."""
        modified_velocity = velocity.copy()
        
        # Wind effect
        if self.environment.wind_strength > 0:
            wind_effect = np.random.normal(0, self.environment.wind_strength * 0.05, 2)
            modified_velocity += wind_effect
        
        # Rain effect (reduces movement)
        if self.environment.rain_intensity > 0:
            rain_factor = 1 - (self.environment.rain_intensity * 0.3)
            modified_velocity *= rain_factor
        
        # Terrain roughness effect
        if self.environment.terrain_roughness > 0:
            roughness_factor = 1 - (self.environment.terrain_roughness * 0.2)
            modified_velocity *= roughness_factor
        
        return modified_velocity
    
    def evaluate_fitness(self, agent) -> float:
        """Evaluate agent fitness based on formation and target proximity."""
        position = np.array(agent['position'])
        target = np.array(self.environment.target_position)
        
        # Distance to target (primary objective)
        distance_to_target = np.linalg.norm(position - target)
        
        # Formation maintenance bonus
        formation_bonus = 0.0
        if not agent['is_leader'] and agent['leader_id'] is not None:
            leader = self.agents[agent['leader_id']]
            leader_pos = np.array(leader['position'])
            actual_distance = np.linalg.norm(position - leader_pos)
            desired_distance = agent['target_following_distance']
            
            # Bonus for maintaining proper following distance
            distance_error = abs(actual_distance - desired_distance)
            formation_bonus = max(0, 5.0 - distance_error)
        
        # Environmental penalties
        obstacle_penalty = 0.0
        for obstacle in self.environment.obstacles:
            obstacle_dist = np.linalg.norm(position - np.array(obstacle['position']))
            if obstacle_dist < obstacle['radius'] + 1.0:
                obstacle_penalty += 10.0
        
        # Linear formation bonus (reward for staying in line)
        linearity_bonus = 0.0
        if len(self.agents) > 2:
            linearity_bonus = self.calculate_linearity_bonus(agent)
        
        fitness = (distance_to_target + obstacle_penalty - 
                  formation_bonus - linearity_bonus)
        
        return float(max(fitness, 0.1))
    
    def calculate_linearity_bonus(self, agent) -> float:
        """Calculate bonus for maintaining linear formation."""
        if len(self.agents) < 3:
            return 0.0
        
        # Check if agent is roughly in line with neighbors
        caterpillar_id = agent['id']
        
        # Get positions of neighbors
        positions = []
        for i in range(max(0, caterpillar_id - 1), min(len(self.agents), caterpillar_id + 2)):
            positions.append(np.array(self.agents[i]['position']))
        
        if len(positions) < 3:
            return 0.0
        
        # Calculate deviation from straight line
        if caterpillar_id == 0:  # Leader
            p1, p2, p3 = positions[0], positions[1], positions[2]
        elif caterpillar_id == len(self.agents) - 1:  # Last
            p1, p2, p3 = positions[-3], positions[-2], positions[-1]
        else:  # Middle
            p1, p2, p3 = positions[0], positions[1], positions[2]
        
        # Calculate angle deviation from straight line
        v1 = p2 - p1
        v2 = p3 - p2
        
        if np.linalg.norm(v1) > 0 and np.linalg.norm(v2) > 0:
            cos_angle = np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2))
            cos_angle = np.clip(cos_angle, -1, 1)
            angle_deviation = abs(np.arccos(cos_angle))
            
            # Bonus for small angle deviation (straight line)
            linearity_bonus = max(0, 2.0 - angle_deviation)
            return linearity_bonus
        
        return 0.0
    
    def get_formation_info(self) -> Dict[str, Any]:
        """Get information about the current formation."""
        formation_info = {
            'leader_position': self.agents[0]['position'],
            'formation_length': 0.0,
            'average_spacing': 0.0,
            'formation_coherence': 0.0
        }
        
        if len(self.agents) > 1:
            # Calculate formation length
            positions = [np.array(agent['position']) for agent in self.agents]
            distances = [np.linalg.norm(positions[i] - positions[i+1]) 
                        for i in range(len(positions) - 1)]
            
            formation_info['formation_length'] = sum(distances)
            formation_info['average_spacing'] = np.mean(distances)
            
            # Calculate coherence (how well agents maintain formation)
            desired_spacing = self.following_distance
            spacing_errors = [abs(d - desired_spacing) for d in distances]
            formation_info['formation_coherence'] = 1.0 / (1.0 + np.mean(spacing_errors))
        
        return formation_info
    
    def get_pheromone_trail(self) -> List[Dict[str, Any]]:
        """Get the current pheromone trail for visualization."""
        return self.pheromone_trail.copy()
