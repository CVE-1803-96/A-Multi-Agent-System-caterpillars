import numpy as np
from abc import ABC, abstractmethod
import random
from typing import Dict, List, Tuple, Any

class BaseOptimizationAlgorithm(ABC):
    """Base class for all bio-inspired optimization algorithms."""
    
    def __init__(self, population_size: int, environment, **kwargs):
        self.population_size = population_size
        self.environment = environment
        self.agents = []
        self.iteration = 0
        self.best_solution = None
        self.best_fitness = float('inf')
        self.fitness_history = []
        self.energy_consumed = 0.0
        self.success_count = 0
        
        # Algorithm-specific parameters
        self.params = kwargs
        
        # Initialize population
        self.initialize_population()
    
    @abstractmethod
    def initialize_population(self):
        """Initialize the population of agents."""
        pass
    
    @abstractmethod
    def update_agents(self):
        """Update agent positions and behaviors."""
        pass
    
    @abstractmethod
    def evaluate_fitness(self, agent) -> float:
        """Evaluate the fitness of an agent."""
        pass
    
    def step(self) -> Dict[str, Any]:
        """Perform one iteration of the algorithm."""
        self.iteration += 1
        
        # Update all agents
        self.update_agents()
        
        # Evaluate fitness and update best solution
        current_best_fitness = float('inf')
        current_best_agent = None
        
        for agent in self.agents:
            fitness = self.evaluate_fitness(agent)
            agent['fitness'] = fitness
            
            if fitness < current_best_fitness:
                current_best_fitness = fitness
                current_best_agent = agent.copy()
        
        # Update global best
        if current_best_agent is not None and current_best_fitness < self.best_fitness:
            self.best_fitness = current_best_fitness
            self.best_solution = current_best_agent.copy()
        
        # Record fitness history
        self.fitness_history.append(current_best_fitness)
        
        # Calculate performance metrics
        metrics = self.calculate_metrics()
        
        # Apply environmental effects
        self.apply_environmental_effects()
        
        return {
            'agents': self.agents,
            'best_solution': self.best_solution,
            'best_fitness': self.best_fitness,
            'iteration': self.iteration,
            'metrics': metrics,
            'environment_effects': self.environment.get_current_effects()
        }
    
    def calculate_metrics(self) -> Dict[str, float]:
        """Calculate performance metrics for the current iteration."""
        # Energy consumption based on agent movements and environmental factors
        movement_energy = sum(np.linalg.norm(agent.get('velocity', [0, 0])) 
                            for agent in self.agents)
        environmental_penalty = (
            self.environment.wind_strength * 0.1 +
            self.environment.rain_intensity * 0.15 +
            self.environment.obstacle_density * 0.2 +
            self.environment.terrain_roughness * 0.05
        )
        
        energy_consumption = (movement_energy / self.population_size) * (1 + environmental_penalty)
        self.energy_consumed += energy_consumption
        
        # Success rate based on agents reaching targets
        agents_at_target = sum(1 for agent in self.agents 
                             if self.is_agent_at_target(agent))
        success_rate = agents_at_target / self.population_size
        
        if agents_at_target > 0:
            self.success_count += 1
        
        # Average velocity
        velocities = [np.linalg.norm(agent.get('velocity', [0, 0])) 
                     for agent in self.agents]
        avg_velocity = np.mean(velocities) if velocities else 0
        
        # Time to target (inverse of progress)
        progress = 1 - (self.best_fitness / 100.0)  # Normalize fitness
        time_to_target = float(1.0 / (progress + 0.001))  # Avoid division by zero
        
        return {
            'energy_consumption': float(energy_consumption),
            'success_rate': float(success_rate),
            'velocity': float(avg_velocity),
            'time_to_target': float(min(time_to_target, 10.0)),  # Cap at 10
            'convergence': float(1.0 / (1.0 + self.best_fitness)),
            'diversity': float(self.calculate_population_diversity())
        }
    
    def calculate_population_diversity(self) -> float:
        """Calculate the diversity of the population."""
        if len(self.agents) < 2:
            return 0.0
        
        positions = [agent['position'] for agent in self.agents]
        distances = []
        
        for i in range(len(positions)):
            for j in range(i + 1, len(positions)):
                dist = np.linalg.norm(np.array(positions[i]) - np.array(positions[j]))
                distances.append(dist)
        
        return float(np.mean(distances)) if distances else 0.0
    
    def is_agent_at_target(self, agent) -> bool:
        """Check if an agent has reached the target."""
        target = self.environment.target_position
        position = agent['position']
        distance = np.linalg.norm(np.array(position) - np.array(target))
        return bool(distance < 2.0)  # Target radius
    
    def apply_environmental_effects(self):
        """Apply environmental effects to agents."""
        for agent in self.agents:
            # Wind effect on velocity
            if self.environment.wind_strength > 0:
                wind_effect = np.random.normal(0, self.environment.wind_strength * 0.1, 2)
                agent['velocity'] = np.array(agent.get('velocity', [0, 0])) + wind_effect
            
            # Rain effect on visibility/sensing
            if self.environment.rain_intensity > 0:
                agent['sensing_range'] = agent.get('base_sensing_range', 5.0) * (1 - self.environment.rain_intensity * 0.3)
            
            # Terrain effect on movement
            if self.environment.terrain_roughness > 0:
                roughness_penalty = 1 - (self.environment.terrain_roughness * 0.2)
                agent['velocity'] = np.array(agent.get('velocity', [0, 0])) * roughness_penalty
    
    def get_population_positions(self) -> List[Tuple[float, float]]:
        """Get the current positions of all agents."""
        return [tuple(agent['position']) for agent in self.agents]
    
    def get_population_fitness(self) -> List[float]:
        """Get the fitness values of all agents."""
        return [agent.get('fitness', float('inf')) for agent in self.agents]
