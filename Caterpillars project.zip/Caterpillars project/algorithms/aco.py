import numpy as np
import random
from typing import Dict, List, Tuple, Any
from .base import BaseOptimizationAlgorithm

class AntColonyOptimization(BaseOptimizationAlgorithm):
    """Ant Colony Optimization algorithm implementation."""
    
    def __init__(self, population_size: int, environment, alpha: float = 1.0, 
                 beta: float = 2.0, evaporation_rate: float = 0.1, 
                 pheromone_constant: float = 10.0, **kwargs):
        
        self.alpha = alpha  # Pheromone importance
        self.beta = beta    # Heuristic importance
        self.evaporation_rate = evaporation_rate
        self.pheromone_constant = pheromone_constant
        
        # Pheromone matrix (grid-based)
        self.grid_size = 50
        self.pheromone_matrix = np.ones((self.grid_size, self.grid_size)) * 0.1
        
        super().__init__(population_size, environment, **kwargs)
    
    def initialize_population(self):
        """Initialize ant population."""
        self.agents = []
        
        for i in range(self.population_size):
            ant = {
                'id': i,
                'position': [
                    random.uniform(0, self.environment.width),
                    random.uniform(0, self.environment.height)
                ],
                'velocity': [0.0, 0.0],
                'path': [],
                'fitness': float('inf'),
                'base_sensing_range': 5.0,
                'sensing_range': 5.0,
                'pheromone_strength': 1.0,
                'carrying_food': False
            }
            self.agents.append(ant)
    
    def update_agents(self):
        """Update ant positions using pheromone-guided movement."""
        # Evaporate pheromones
        self.pheromone_matrix *= (1 - self.evaporation_rate)
        self.pheromone_matrix = np.maximum(self.pheromone_matrix, 0.01)  # Minimum pheromone level
        
        for ant in self.agents:
            # Ant decision making based on pheromone and heuristic information
            next_position = self.choose_next_position(ant)
            
            # Update velocity and position
            current_pos = np.array(ant['position'])
            velocity = np.array(next_position) - current_pos
            
            # Limit velocity magnitude
            max_velocity = 2.0
            velocity_magnitude = np.linalg.norm(velocity)
            if velocity_magnitude > max_velocity:
                velocity = velocity * (max_velocity / velocity_magnitude)
            
            ant['velocity'] = velocity.tolist()
            ant['position'] = (current_pos + velocity).tolist()
            
            # Keep agents within bounds
            ant['position'][0] = np.clip(ant['position'][0], 0, self.environment.width)
            ant['position'][1] = np.clip(ant['position'][1], 0, self.environment.height)
            
            # Update path
            ant['path'].append(ant['position'].copy())
            
            # Deposit pheromone
            self.deposit_pheromone(ant)
    
    def choose_next_position(self, ant) -> List[float]:
        """Choose next position based on pheromone trails and heuristic information."""
        current_pos = np.array(ant['position'])
        target_pos = np.array(self.environment.target_position)
        
        # Generate candidate positions around the ant
        num_candidates = 8
        angles = np.linspace(0, 2 * np.pi, num_candidates, endpoint=False)
        step_size = 1.5
        
        candidates = []
        probabilities = []
        
        for angle in angles:
            candidate_pos = current_pos + step_size * np.array([np.cos(angle), np.sin(angle)])
            
            # Check bounds
            if (0 <= candidate_pos[0] <= self.environment.width and 
                0 <= candidate_pos[1] <= self.environment.height):
                
                # Get pheromone level at candidate position
                grid_x = int(np.clip(candidate_pos[0] / self.environment.width * self.grid_size, 0, self.grid_size - 1))
                grid_y = int(np.clip(candidate_pos[1] / self.environment.height * self.grid_size, 0, self.grid_size - 1))
                pheromone_level = self.pheromone_matrix[grid_y, grid_x]
                
                # Calculate heuristic (inverse of distance to target)
                distance_to_target = np.linalg.norm(candidate_pos - target_pos)
                heuristic = 1.0 / (distance_to_target + 0.1)
                
                # Calculate probability based on ACO formula
                probability = (pheromone_level ** self.alpha) * (heuristic ** self.beta)
                
                candidates.append(candidate_pos)
                probabilities.append(probability)
        
        if not candidates:
            # If no valid candidates, move randomly
            angle = random.uniform(0, 2 * np.pi)
            return (current_pos + step_size * np.array([np.cos(angle), np.sin(angle)])).tolist()
        
        # Normalize probabilities
        total_prob = sum(probabilities)
        if total_prob > 0:
            probabilities = [p / total_prob for p in probabilities]
        else:
            probabilities = [1.0 / len(candidates)] * len(candidates)
        
        # Select position based on probabilities
        selected_idx = np.random.choice(len(candidates), p=probabilities)
        return candidates[selected_idx].tolist()
    
    def deposit_pheromone(self, ant):
        """Deposit pheromone at ant's current position."""
        position = ant['position']
        
        # Convert position to grid coordinates
        grid_x = int(np.clip(position[0] / self.environment.width * self.grid_size, 0, self.grid_size - 1))
        grid_y = int(np.clip(position[1] / self.environment.height * self.grid_size, 0, self.grid_size - 1))
        
        # Deposit pheromone (higher for better solutions)
        pheromone_amount = self.pheromone_constant / (ant.get('fitness', 100) + 1)
        self.pheromone_matrix[grid_y, grid_x] += pheromone_amount
        
        # Optional: diffuse pheromone to neighboring cells
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                if dx == 0 and dy == 0:
                    continue
                
                neighbor_x = grid_x + dx
                neighbor_y = grid_y + dy
                
                if (0 <= neighbor_x < self.grid_size and 
                    0 <= neighbor_y < self.grid_size):
                    self.pheromone_matrix[neighbor_y, neighbor_x] += pheromone_amount * 0.1
    
    def evaluate_fitness(self, agent) -> float:
        """Evaluate the fitness of an agent (distance to target)."""
        position = np.array(agent['position'])
        target = np.array(self.environment.target_position)
        
        # Primary fitness: distance to target
        distance_to_target = np.linalg.norm(position - target)
        
        # Secondary fitness components
        path_length = len(agent.get('path', []))
        path_efficiency = 1.0 if path_length == 0 else min(50.0 / path_length, 1.0)
        
        # Environmental penalties
        obstacle_penalty = 0.0
        for obstacle in self.environment.obstacles:
            obstacle_dist = np.linalg.norm(position - np.array(obstacle['position']))
            if obstacle_dist < obstacle['radius'] + 1.0:
                obstacle_penalty += 10.0
        
        fitness = distance_to_target + obstacle_penalty - (path_efficiency * 5.0)
        return float(max(fitness, 0.1))  # Ensure positive fitness
    
    def get_pheromone_trails(self) -> np.ndarray:
        """Get the current pheromone matrix for visualization."""
        return self.pheromone_matrix.copy()
    
    def get_algorithm_state(self) -> Dict[str, Any]:
        """Get additional algorithm-specific state information."""
        return {
            'pheromone_matrix': self.pheromone_matrix,
            'evaporation_rate': self.evaporation_rate,
            'alpha': self.alpha,
            'beta': self.beta,
            'grid_size': self.grid_size
        }
