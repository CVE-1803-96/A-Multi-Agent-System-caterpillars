import numpy as np
import random
from typing import Dict, List, Tuple, Any
from .base import BaseOptimizationAlgorithm

class WolfOptimization(BaseOptimizationAlgorithm):
    """Wolf Optimization Algorithm implementation."""
    
    def __init__(self, population_size: int, environment, a_decay: float = 2.0,
                 pack_size: int = 20, alpha_influence: float = 0.8,
                 beta_influence: float = 0.6, **kwargs):
        
        self.a_decay = a_decay  # Convergence parameter
        self.pack_size = min(pack_size, population_size)
        self.alpha_influence = alpha_influence
        self.beta_influence = beta_influence
        
        # Wolf hierarchy
        self.alpha_wolf = None
        self.beta_wolf = None
        self.delta_wolf = None
        
        # Pack coordination variables
        self.pack_center = [0.0, 0.0]
        self.hunting_phase = "search"  # search, encircle, attack
        
        super().__init__(population_size, environment, **kwargs)
    
    def initialize_population(self):
        """Initialize wolf population."""
        self.agents = []
        
        for i in range(self.population_size):
            wolf = {
                'id': i,
                'position': [
                    random.uniform(0, self.environment.width),
                    random.uniform(0, self.environment.height)
                ],
                'velocity': [0.0, 0.0],
                'fitness': float('inf'),
                'rank': 'omega',  # alpha, beta, delta, omega
                'base_sensing_range': 6.0,
                'sensing_range': 6.0,
                'hunting_effectiveness': random.uniform(0.7, 1.0),
                'pack_coordination': random.uniform(0.5, 1.0),
                'a': self.a_decay  # Individual convergence parameter
            }
            self.agents.append(wolf)
    
    def update_agents(self):
        """Update wolf positions using pack hunting strategy."""
        # Update convergence parameter
        self.update_convergence_parameter()
        
        # Identify hierarchy (alpha, beta, delta wolves)
        self.identify_hierarchy()
        
        # Update pack center
        self.update_pack_center()
        
        # Determine hunting phase
        self.determine_hunting_phase()
        
        # Update each wolf based on hierarchy and hunting phase
        for wolf in self.agents:
            self.update_wolf_position(wolf)
    
    def update_convergence_parameter(self):
        """Update the convergence parameter 'a'."""
        # Decrease 'a' linearly from 2 to 0
        progress = self.iteration / 100.0  # Assuming max 100 iterations
        a = self.a_decay * (1 - min(progress, 1.0))
        
        for wolf in self.agents:
            wolf['a'] = a
    
    def identify_hierarchy(self):
        """Identify alpha, beta, and delta wolves based on fitness."""
        # Sort wolves by fitness (best fitness first)
        sorted_wolves = sorted(self.agents, key=lambda w: w['fitness'])
        
        # Assign ranks
        for i, wolf in enumerate(sorted_wolves):
            if i == 0:
                wolf['rank'] = 'alpha'
                self.alpha_wolf = wolf
            elif i == 1:
                wolf['rank'] = 'beta'
                self.beta_wolf = wolf
            elif i == 2:
                wolf['rank'] = 'delta'
                self.delta_wolf = wolf
            else:
                wolf['rank'] = 'omega'
    
    def update_pack_center(self):
        """Update the center of the pack."""
        if not self.agents:
            return
        
        positions = [wolf['position'] for wolf in self.agents]
        self.pack_center = [
            sum(pos[0] for pos in positions) / len(positions),
            sum(pos[1] for pos in positions) / len(positions)
        ]
    
    def determine_hunting_phase(self):
        """Determine the current hunting phase."""
        if not self.alpha_wolf:
            self.hunting_phase = "search"
            return
        
        alpha_pos = np.array(self.alpha_wolf['position'])
        target_pos = np.array(self.environment.target_position)
        distance_to_target = np.linalg.norm(alpha_pos - target_pos)
        
        # Determine phase based on alpha wolf's distance to target
        if distance_to_target > 15.0:
            self.hunting_phase = "search"
        elif distance_to_target > 5.0:
            self.hunting_phase = "encircle"
        else:
            self.hunting_phase = "attack"
    
    def update_wolf_position(self, wolf):
        """Update individual wolf position based on pack behavior."""
        current_pos = np.array(wolf['position'])
        
        if wolf['rank'] == 'alpha':
            # Alpha wolf leads towards target with some exploration
            new_position = self.update_alpha_position(wolf)
        elif wolf['rank'] in ['beta', 'delta']:
            # Beta and delta wolves support alpha
            new_position = self.update_supporting_wolf_position(wolf)
        else:
            # Omega wolves follow the pack hierarchy
            new_position = self.update_omega_position(wolf)
        
        # Apply environmental effects
        velocity = new_position - current_pos
        velocity = self.apply_environmental_effects_to_velocity(velocity, wolf)
        new_position = current_pos + velocity
        
        # Keep within bounds
        new_position[0] = np.clip(new_position[0], 0, self.environment.width)
        new_position[1] = np.clip(new_position[1], 0, self.environment.height)
        
        wolf['velocity'] = velocity.tolist()
        wolf['position'] = new_position.tolist()
    
    def update_alpha_position(self, alpha_wolf):
        """Update alpha wolf position (pack leader)."""
        current_pos = np.array(alpha_wolf['position'])
        target_pos = np.array(self.environment.target_position)
        
        # Move towards target with leadership behavior
        direction_to_target = target_pos - current_pos
        distance_to_target = np.linalg.norm(direction_to_target)
        
        if distance_to_target > 0:
            direction_to_target = direction_to_target / distance_to_target
        
        # Add exploration component
        exploration_strength = alpha_wolf['a'] / self.a_decay  # Decreases over time
        exploration = np.random.normal(0, exploration_strength * 0.5, 2)
        
        # Combine target-seeking with exploration
        step_size = 1.5
        new_position = current_pos + (direction_to_target * step_size + exploration)
        
        return new_position
    
    def update_supporting_wolf_position(self, wolf):
        """Update beta or delta wolf position."""
        current_pos = np.array(wolf['position'])
        
        if not self.alpha_wolf:
            return current_pos
        
        alpha_pos = np.array(self.alpha_wolf['position'])
        target_pos = np.array(self.environment.target_position)
        
        # Support alpha wolf while maintaining formation
        if self.hunting_phase == "search":
            # During search, explore around alpha
            direction_to_alpha = alpha_pos - current_pos
            distance_to_alpha = np.linalg.norm(direction_to_alpha)
            
            if distance_to_alpha > 8.0:  # Too far from alpha
                direction_to_alpha = direction_to_alpha / distance_to_alpha if distance_to_alpha > 0 else np.array([0, 0])
                new_position = current_pos + direction_to_alpha * 1.2
            else:
                # Explore around alpha
                angle = random.uniform(0, 2 * np.pi)
                exploration_radius = 3.0
                offset = exploration_radius * np.array([np.cos(angle), np.sin(angle)])
                new_position = alpha_pos + offset
        
        elif self.hunting_phase == "encircle":
            # Encircle the target
            new_position = self.encircle_target(wolf, target_pos)
        
        else:  # attack phase
            # Direct attack towards target
            direction_to_target = target_pos - current_pos
            distance_to_target = np.linalg.norm(direction_to_target)
            
            if distance_to_target > 0:
                direction_to_target = direction_to_target / distance_to_target
            
            attack_speed = 2.0
            new_position = current_pos + direction_to_target * attack_speed
        
        return new_position
    
    def update_omega_position(self, wolf):
        """Update omega wolf position using Grey Wolf Optimizer algorithm."""
        current_pos = np.array(wolf['position'])
        
        if not all([self.alpha_wolf, self.beta_wolf, self.delta_wolf]):
            # If hierarchy not established, move randomly
            direction = np.random.uniform(-1, 1, 2)
            return current_pos + direction
        
        # Standard GWO position update
        alpha_pos = np.array(self.alpha_wolf['position']) if self.alpha_wolf else current_pos
        beta_pos = np.array(self.beta_wolf['position']) if self.beta_wolf else current_pos
        delta_pos = np.array(self.delta_wolf['position']) if self.delta_wolf else current_pos
        
        a = wolf['a']
        
        # Calculate A and C vectors for each leader
        A1, C1 = self.calculate_coefficients(a)
        A2, C2 = self.calculate_coefficients(a)
        A3, C3 = self.calculate_coefficients(a)
        
        # Calculate distances and positions relative to alpha, beta, delta
        D_alpha = abs(C1 * alpha_pos - current_pos)
        D_beta = abs(C2 * beta_pos - current_pos)
        D_delta = abs(C3 * delta_pos - current_pos)
        
        X1 = alpha_pos - A1 * D_alpha
        X2 = beta_pos - A2 * D_beta
        X3 = delta_pos - A3 * D_delta
        
        # Update position
        new_position = (X1 + X2 + X3) / 3.0
        
        return new_position
    
    def calculate_coefficients(self, a):
        """Calculate A and C coefficient vectors for GWO."""
        r1 = np.random.random(2)
        r2 = np.random.random(2)
        
        A = 2 * a * r1 - a
        C = 2 * r2
        
        return A, C
    
    def encircle_target(self, wolf, target_pos):
        """Calculate encircling position around target."""
        current_pos = np.array(wolf['position'])
        
        # Calculate desired position in circle around target
        center_to_wolf = current_pos - target_pos
        distance_to_target = np.linalg.norm(center_to_wolf)
        
        if distance_to_target == 0:
            return current_pos
        
        # Desired encircling radius
        encircle_radius = 5.0
        
        # Current angle around target
        current_angle = np.arctan2(center_to_wolf[1], center_to_wolf[0])
        
        # Move to desired radius while rotating around target
        angle_increment = 0.1  # Slow rotation
        new_angle = current_angle + angle_increment
        
        # Calculate new position
        new_position = target_pos + encircle_radius * np.array([
            np.cos(new_angle),
            np.sin(new_angle)
        ])
        
        return new_position
    
    def apply_environmental_effects_to_velocity(self, velocity, wolf):
        """Apply environmental effects to wolf velocity."""
        modified_velocity = velocity.copy()
        
        # Wind effect
        if self.environment.wind_strength > 0:
            wind_effect = np.random.normal(0, self.environment.wind_strength * 0.08, 2)
            modified_velocity += wind_effect
        
        # Rain effect (reduces hunting effectiveness)
        if self.environment.rain_intensity > 0:
            rain_factor = 1 - (self.environment.rain_intensity * 0.4)
            modified_velocity *= rain_factor
        
        # Terrain effect
        if self.environment.terrain_roughness > 0:
            terrain_factor = 1 - (self.environment.terrain_roughness * 0.3)
            modified_velocity *= terrain_factor
        
        # Limit velocity based on wolf's effectiveness
        max_velocity = float(2.5 * wolf['hunting_effectiveness'])
        velocity_magnitude = np.linalg.norm(modified_velocity)
        if velocity_magnitude > max_velocity:
            modified_velocity = modified_velocity * (max_velocity / velocity_magnitude)
        
        return modified_velocity
    
    def evaluate_fitness(self, agent) -> float:
        """Evaluate agent fitness based on hunting success and pack coordination."""
        position = np.array(agent['position'])
        target = np.array(self.environment.target_position)
        
        # Distance to target (primary objective)
        distance_to_target = np.linalg.norm(position - target)
        
        # Pack coordination bonus
        pack_coordination_bonus = 0.0
        if agent['rank'] != 'alpha':
            # Reward wolves for staying coordinated with pack
            pack_center = np.array(self.pack_center)
            distance_to_pack = np.linalg.norm(position - pack_center)
            pack_coordination_bonus = max(0, 10.0 - distance_to_pack) * agent['pack_coordination']
        
        # Hierarchy bonus
        hierarchy_bonus = 0.0
        if agent['rank'] == 'alpha':
            hierarchy_bonus = 5.0  # Leadership bonus
        elif agent['rank'] == 'beta':
            hierarchy_bonus = 3.0
        elif agent['rank'] == 'delta':
            hierarchy_bonus = 1.0
        
        # Environmental penalties
        obstacle_penalty = 0.0
        for obstacle in self.environment.obstacles:
            obstacle_dist = np.linalg.norm(position - np.array(obstacle['position']))
            if obstacle_dist < obstacle['radius'] + 1.0:
                obstacle_penalty += 15.0  # Wolves are more affected by obstacles
        
        # Hunting phase effectiveness
        phase_bonus = 0.0
        if self.hunting_phase == "attack" and distance_to_target < 5.0:
            phase_bonus = 3.0 * agent['hunting_effectiveness']
        elif self.hunting_phase == "encircle" and 5.0 <= distance_to_target <= 15.0:
            phase_bonus = 2.0 * agent['hunting_effectiveness']
        
        fitness = (distance_to_target + obstacle_penalty - 
                  pack_coordination_bonus - hierarchy_bonus - phase_bonus)
        
        return float(max(fitness, 0.1))
    
    def get_pack_info(self):
        """Get information about the current pack state."""
        pack_info = {
            'alpha_wolf': self.alpha_wolf['id'] if self.alpha_wolf else None,
            'beta_wolf': self.beta_wolf['id'] if self.beta_wolf else None,
            'delta_wolf': self.delta_wolf['id'] if self.delta_wolf else None,
            'pack_center': self.pack_center,
            'hunting_phase': self.hunting_phase,
            'convergence_parameter': self.agents[0]['a'] if self.agents else 0,
            'pack_cohesion': self.calculate_pack_cohesion()
        }
        return pack_info
    
    def calculate_pack_cohesion(self):
        """Calculate how cohesive the pack is."""
        if len(self.agents) < 2:
            return 1.0
        
        pack_center = np.array(self.pack_center)
        distances = [np.linalg.norm(np.array(wolf['position']) - pack_center) 
                    for wolf in self.agents]
        
        avg_distance = np.mean(distances)
        # Cohesion is high when average distance to center is low
        cohesion = 1.0 / (1.0 + avg_distance / 10.0)
        
        return cohesion
