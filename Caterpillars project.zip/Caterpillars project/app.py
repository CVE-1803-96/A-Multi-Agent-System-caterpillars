import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
import time
import json
from datetime import datetime
import io

# Import custom modules
from algorithms.aco import AntColonyOptimization
from algorithms.caterpillar import ProcessionaryCaterpillar
from algorithms.wolf import WolfOptimization
from utils.visualization import create_movement_plot, create_pheromone_plot, create_performance_comparison
from utils.metrics import calculate_performance_metrics, export_results
from utils.environment import Environment

# Page configuration
st.set_page_config(
    page_title="Bio-Inspired Optimization Algorithms Comparison",
    page_icon="🐜",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for university branding
st.markdown("""
    <style>
    .main-header {
        background: linear-gradient(90deg, #1e3a8a 0%, #3b82f6 100%);
        padding: 1rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        text-align: center;
        color: white;
    }
    .algorithm-card {
        background: #f8fafc;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #3b82f6;
        margin-bottom: 1rem;
    }
    .metric-card {
        background: #ffffff;
        padding: 1rem;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        text-align: center;
    }
    .footer {
        text-align: center;
        padding: 2rem 0;
        border-top: 1px solid #e5e7eb;
        margin-top: 3rem;
        color: #6b7280;
    }
    </style>
""", unsafe_allow_html=True)

# University header
st.markdown("""
    <div class="main-header">
        <h1>🎓 University of Djillali Liabes Sidi Bel Abbes</h1>
        <h2>Bio-Inspired Optimization Algorithms Comparison Tool</h2>
        <p>Interactive Visualization and Performance Analysis Dashboard</p>
    </div>
""", unsafe_allow_html=True)

# Initialize session state
if 'simulation_running' not in st.session_state:
    st.session_state.simulation_running = False
if 'results_history' not in st.session_state:
    st.session_state.results_history = []

# Sidebar configuration
st.sidebar.header("🔧 Algorithm Configuration")

# Algorithm selection
selected_algorithms = st.sidebar.multiselect(
    "Select Algorithms to Compare",
    ["Ant Colony Optimization (ACO)", "Processionary Caterpillar", "Wolf Optimization"],
    default=["Ant Colony Optimization (ACO)", "Processionary Caterpillar", "Wolf Optimization"]
)

# Environment parameters
st.sidebar.subheader("🌍 Environmental Conditions")
wind_strength = st.sidebar.slider("Wind Strength", 0.0, 1.0, 0.2, 0.1)
rain_intensity = st.sidebar.slider("Rain Intensity", 0.0, 1.0, 0.1, 0.1)
obstacle_density = st.sidebar.slider("Obstacle Density", 0.0, 0.5, 0.1, 0.05)
terrain_roughness = st.sidebar.slider("Terrain Roughness", 0.0, 1.0, 0.3, 0.1)

# Simulation parameters
st.sidebar.subheader("⚙️ Simulation Parameters")
population_size = st.sidebar.slider("Population Size", 10, 200, 50, 10)
max_iterations = st.sidebar.slider("Maximum Iterations", 50, 500, 100, 25)
simulation_speed = st.sidebar.slider("Simulation Speed", 0.1, 2.0, 1.0, 0.1)

# Algorithm-specific parameters
algorithm_params = {}

if "Ant Colony Optimization (ACO)" in selected_algorithms:
    st.sidebar.subheader("🐜 ACO Parameters")
    algorithm_params['aco'] = {
        'alpha': st.sidebar.slider("Pheromone Importance (α)", 0.1, 3.0, 1.0, 0.1),
        'beta': st.sidebar.slider("Heuristic Importance (β)", 0.1, 5.0, 2.0, 0.1),
        'evaporation_rate': st.sidebar.slider("Evaporation Rate", 0.01, 0.5, 0.1, 0.01),
        'pheromone_constant': st.sidebar.slider("Pheromone Constant", 1.0, 100.0, 10.0, 1.0)
    }

if "Processionary Caterpillar" in selected_algorithms:
    st.sidebar.subheader("🐛 Caterpillar Parameters")
    algorithm_params['caterpillar'] = {
        'following_distance': st.sidebar.slider("Following Distance", 0.5, 3.0, 1.0, 0.1),
        'leader_influence': st.sidebar.slider("Leader Influence", 0.1, 1.0, 0.7, 0.1),
        'pheromone_strength': st.sidebar.slider("Pheromone Trail Strength", 0.1, 2.0, 1.0, 0.1),
        'formation_flexibility': st.sidebar.slider("Formation Flexibility", 0.1, 1.0, 0.5, 0.1)
    }

if "Wolf Optimization" in selected_algorithms:
    st.sidebar.subheader("🐺 Wolf Parameters")
    algorithm_params['wolf'] = {
        'a_decay': st.sidebar.slider("Convergence Parameter (a)", 0.01, 2.0, 2.0, 0.01),
        'pack_size': st.sidebar.slider("Pack Size", 5, 50, 20, 5),
        'alpha_influence': st.sidebar.slider("Alpha Wolf Influence", 0.1, 1.0, 0.8, 0.1),
        'beta_influence': st.sidebar.slider("Beta Wolf Influence", 0.1, 1.0, 0.6, 0.1)
    }

# Main content area
col1, col2 = st.columns([2, 1])

with col1:
    # Control buttons
    control_col1, control_col2, control_col3 = st.columns(3)
    
    with control_col1:
        if st.button("🚀 Start Simulation", type="primary"):
            st.session_state.simulation_running = True
    
    with control_col2:
        if st.button("⏹️ Stop Simulation"):
            st.session_state.simulation_running = False
    
    with control_col3:
        if st.button("🔄 Reset"):
            st.session_state.simulation_running = False
            st.session_state.results_history = []
            st.rerun()

    # Algorithm comparison tabs
    tab1, tab2, tab3, tab4 = st.tabs(["🎯 Live Simulation", "📊 Performance Metrics", "🌍 Environmental Impact", "📈 Comparative Analysis"])
    
    with tab1:
        if st.session_state.simulation_running and selected_algorithms:
            # Create environment
            environment = Environment(
                wind_strength=wind_strength,
                rain_intensity=rain_intensity,
                obstacle_density=obstacle_density,
                terrain_roughness=terrain_roughness
            )
            
            # Initialize algorithms
            algorithms = {}
            if "Ant Colony Optimization (ACO)" in selected_algorithms:
                algorithms['ACO'] = AntColonyOptimization(
                    population_size=population_size,
                    environment=environment,
                    **algorithm_params.get('aco', {})
                )
            
            if "Processionary Caterpillar" in selected_algorithms:
                algorithms['Caterpillar'] = ProcessionaryCaterpillar(
                    population_size=population_size,
                    environment=environment,
                    **algorithm_params.get('caterpillar', {})
                )
            
            if "Wolf Optimization" in selected_algorithms:
                algorithms['Wolf'] = WolfOptimization(
                    population_size=population_size,
                    environment=environment,
                    **algorithm_params.get('wolf', {})
                )
            
            # Simulation visualization placeholder
            simulation_placeholder = st.empty()
            
            # Run simulation iterations
            for iteration in range(max_iterations):
                if not st.session_state.simulation_running:
                    break
                
                # Update each algorithm
                algorithm_data = {}
                for name, algorithm in algorithms.items():
                    result = algorithm.step()
                    algorithm_data[name] = result
                
                # Create real-time visualization
                fig = create_movement_plot(algorithm_data, environment, iteration)
                simulation_placeholder.plotly_chart(fig, use_container_width=True)
                
                # Control simulation speed
                time.sleep(1.0 / simulation_speed)
                
                # Store results for analysis
                if iteration % 10 == 0:  # Store every 10th iteration
                    metrics = calculate_performance_metrics(algorithm_data)
                    result_entry = {
                        'iteration': iteration,
                        'timestamp': datetime.now()
                    }
                    result_entry.update(metrics)
                    st.session_state.results_history.append(result_entry)
        
        else:
            st.info("👆 Select algorithms and click 'Start Simulation' to begin the comparison.")
            
            # Show static algorithm information
            if selected_algorithms:
                for algo in selected_algorithms:
                    if algo == "Ant Colony Optimization (ACO)":
                        st.markdown("""
                            <div class="algorithm-card">
                                <h4>🐜 Ant Colony Optimization (ACO)</h4>
                                <p><strong>Principle:</strong> Stigmergic coordination through pheromone trails</p>
                                <p><strong>Behavior:</strong> Indirect communication, emergent shortest paths</p>
                                <p><strong>Applications:</strong> Routing, logistics, network optimization</p>
                            </div>
                        """, unsafe_allow_html=True)
                    
                    elif algo == "Processionary Caterpillar":
                        st.markdown("""
                            <div class="algorithm-card">
                                <h4>🐛 Processionary Caterpillar</h4>
                                <p><strong>Principle:</strong> Linear formation and leader-follower dynamics</p>
                                <p><strong>Behavior:</strong> Hierarchical coordination, distance maintenance</p>
                                <p><strong>Applications:</strong> Convoy management, formation control</p>
                            </div>
                        """, unsafe_allow_html=True)
                    
                    elif algo == "Wolf Optimization":
                        st.markdown("""
                            <div class="algorithm-card">
                                <h4>🐺 Wolf Optimization</h4>
                                <p><strong>Principle:</strong> Pack hunting with alpha, beta, delta hierarchy</p>
                                <p><strong>Behavior:</strong> Encircling prey, coordinated hunting strategy</p>
                                <p><strong>Applications:</strong> Global optimization, feature selection</p>
                            </div>
                        """, unsafe_allow_html=True)
    
    with tab2:
        if st.session_state.results_history:
            # Create performance metrics visualization
            metrics_df = pd.DataFrame([
                {
                    'iteration': result['iteration'],
                    'algorithm': algo,
                    'energy_consumption': result.get(algo, {}).get('energy_consumption', 0),
                    'success_rate': result.get(algo, {}).get('success_rate', 0),
                    'time_to_target': result.get(algo, {}).get('time_to_target', 0),
                    'velocity': result.get(algo, {}).get('velocity', 0)
                }
                for result in st.session_state.results_history
                for algo in result.keys() if algo not in ['iteration', 'timestamp']
            ])
            
            if not metrics_df.empty:
                # Energy consumption over time
                fig_energy = px.line(metrics_df, x='iteration', y='energy_consumption', 
                                   color='algorithm', title='Energy Consumption Over Time')
                st.plotly_chart(fig_energy, use_container_width=True)
                
                # Success rate comparison
                fig_success = px.line(metrics_df, x='iteration', y='success_rate', 
                                    color='algorithm', title='Success Rate Over Time')
                st.plotly_chart(fig_success, use_container_width=True)
                
                # Performance summary table
                summary_stats = metrics_df.groupby('algorithm').agg({
                    'energy_consumption': ['mean', 'std'],
                    'success_rate': ['mean', 'std'],
                    'time_to_target': ['mean', 'std'],
                    'velocity': ['mean', 'std']
                }).round(3)
                
                st.subheader("📋 Performance Summary Statistics")
                st.dataframe(summary_stats, use_container_width=True)
        else:
            st.info("Run a simulation to see performance metrics.")
    
    with tab3:
        # Environmental impact analysis
        if st.session_state.results_history:
            st.subheader("🌦️ Environmental Factors Impact")
            
            # Current environmental conditions
            env_col1, env_col2, env_col3, env_col4 = st.columns(4)
            
            with env_col1:
                st.metric("Wind Strength", f"{wind_strength:.1f}", 
                         delta=f"{'High' if wind_strength > 0.5 else 'Low'} Impact")
            
            with env_col2:
                st.metric("Rain Intensity", f"{rain_intensity:.1f}", 
                         delta=f"{'High' if rain_intensity > 0.5 else 'Low'} Impact")
            
            with env_col3:
                st.metric("Obstacle Density", f"{obstacle_density:.1f}", 
                         delta=f"{'High' if obstacle_density > 0.25 else 'Low'} Impact")
            
            with env_col4:
                st.metric("Terrain Roughness", f"{terrain_roughness:.1f}", 
                         delta=f"{'High' if terrain_roughness > 0.5 else 'Low'} Impact")
            
            # Environmental sensitivity analysis
            if len(st.session_state.results_history) > 5:
                latest_results = st.session_state.results_history[-1]
                
                # Create radar chart for environmental sensitivity
                categories = ['Wind Resistance', 'Rain Adaptation', 'Obstacle Avoidance', 'Terrain Navigation']
                
                fig_radar = go.Figure()
                
                for algo in selected_algorithms:
                    algo_short = algo.split()[0]  # Get first word
                    if algo_short in latest_results:
                        values = [
                            1 - (wind_strength * 0.5),  # Wind resistance (inverse of impact)
                            1 - (rain_intensity * 0.4),  # Rain adaptation
                            1 - (obstacle_density * 0.8),  # Obstacle avoidance
                            1 - (terrain_roughness * 0.3)  # Terrain navigation
                        ]
                        
                        fig_radar.add_trace(go.Scatterpolar(
                            r=values,
                            theta=categories,
                            fill='toself',
                            name=algo_short,
                            line=dict(width=2)
                        ))
                
                fig_radar.update_layout(
                    polar=dict(
                        radialaxis=dict(
                            visible=True,
                            range=[0, 1]
                        )),
                    showlegend=True,
                    title="Environmental Adaptation Capabilities"
                )
                
                st.plotly_chart(fig_radar, use_container_width=True)
        else:
            st.info("Run a simulation to analyze environmental impact.")
    
    with tab4:
        # Comparative analysis
        if st.session_state.results_history and len(selected_algorithms) > 1:
            st.subheader("🏆 Algorithm Performance Comparison")
            
            # Performance ranking
            latest_results = st.session_state.results_history[-1]
            performance_scores = {}
            
            for algo in selected_algorithms:
                algo_short = algo.split()[0]
                if algo_short in latest_results:
                    score = (
                        latest_results[algo_short].get('success_rate', 0) * 0.4 +
                        (1 - latest_results[algo_short].get('energy_consumption', 1)) * 0.3 +
                        latest_results[algo_short].get('velocity', 0) * 0.2 +
                        (1 - latest_results[algo_short].get('time_to_target', 1)) * 0.1
                    )
                    performance_scores[algo_short] = score
            
            # Ranking visualization
            if performance_scores:
                ranking_data = [{'Algorithm': k, 'Performance Score': v} for k, v in performance_scores.items()]
                ranking_df = pd.DataFrame(ranking_data)
                ranking_df = ranking_df.sort_values('Performance Score', ascending=False)
                
                fig_ranking = px.bar(ranking_df, x='Algorithm', y='Performance Score',
                                   title='Overall Performance Ranking',
                                   color='Performance Score',
                                   color_continuous_scale='viridis')
                st.plotly_chart(fig_ranking, use_container_width=True)
                
                # Detailed comparison table
                st.subheader("📊 Detailed Performance Comparison")
                comparison_data = []
                for algo_short, score in performance_scores.items():
                    algo_data = latest_results[algo_short]
                    comparison_data.append({
                        'Algorithm': algo_short,
                        'Overall Score': f"{score:.3f}",
                        'Energy Efficiency': f"{1 - algo_data.get('energy_consumption', 1):.3f}",
                        'Success Rate': f"{algo_data.get('success_rate', 0):.3f}",
                        'Velocity': f"{algo_data.get('velocity', 0):.3f}",
                        'Time Efficiency': f"{1 - algo_data.get('time_to_target', 1):.3f}"
                    })
                
                comparison_df = pd.DataFrame(comparison_data)
                st.dataframe(comparison_df, use_container_width=True)
        else:
            st.info("Run simulations with multiple algorithms to see comparative analysis.")

with col2:
    # Real-time metrics panel
    st.subheader("📊 Real-Time Metrics")
    
    if st.session_state.results_history:
        latest_results = st.session_state.results_history[-1]
        
        for algo in selected_algorithms:
            algo_short = algo.split()[0]
            if algo_short in latest_results:
                with st.container():
                    st.markdown(f"**{algo_short}**")
                    
                    metrics_data = latest_results[algo_short]
                    
                    # Energy consumption
                    energy = metrics_data.get('energy_consumption', 0)
                    st.metric("Energy", f"{energy:.3f}", 
                             delta=f"{'High' if energy > 0.5 else 'Efficient'}")
                    
                    # Success rate
                    success = metrics_data.get('success_rate', 0)
                    st.metric("Success Rate", f"{success:.1%}")
                    
                    # Velocity
                    velocity = metrics_data.get('velocity', 0)
                    st.metric("Velocity", f"{velocity:.3f}")
                    
                    st.markdown("---")
    
    # Export functionality
    st.subheader("💾 Export Results")
    
    if st.session_state.results_history:
        export_format = st.selectbox("Export Format", ["CSV", "JSON"])
        
        if st.button("📥 Download Results"):
            if export_format == "CSV":
                # Flatten results for CSV export
                export_data = []
                for result in st.session_state.results_history:
                    for algo, metrics in result.items():
                        if algo not in ['iteration', 'timestamp']:
                            row = {
                                'timestamp': result['timestamp'],
                                'iteration': result['iteration'],
                                'algorithm': algo,
                                **metrics
                            }
                            export_data.append(row)
                
                df = pd.DataFrame(export_data)
                csv = df.to_csv(index=False)
                
                st.download_button(
                    label="Download CSV",
                    data=csv,
                    file_name=f"bio_algorithms_comparison_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                    mime="text/csv"
                )
            
            elif export_format == "JSON":
                json_data = json.dumps(st.session_state.results_history, 
                                     default=str, indent=2)
                
                st.download_button(
                    label="Download JSON",
                    data=json_data,
                    file_name=f"bio_algorithms_comparison_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                    mime="application/json"
                )
    
    # Algorithm information panel
    st.subheader("ℹ️ Algorithm Info")
    
    info_algo = st.selectbox("Select Algorithm", selected_algorithms if selected_algorithms else ["None"])
    
    if info_algo and info_algo != "None":
        if info_algo == "Ant Colony Optimization (ACO)":
            st.markdown("""
                **Key Features:**
                - Pheromone-based communication
                - Stigmergic coordination
                - Emergent path optimization
                - Adaptive to dynamic environments
                
                **Strengths:**
                - Excellent for pathfinding
                - Self-organizing behavior
                - Robust to individual failures
                
                **Applications:**
                - Vehicle routing
                - Network optimization
                - Resource allocation
            """)
        
        elif info_algo == "Processionary Caterpillar":
            st.markdown("""
                **Key Features:**
                - Linear formation control
                - Leader-follower dynamics
                - Distance maintenance
                - Chemical trail following
                
                **Strengths:**
                - Stable formations
                - Predictable behavior
                - Energy efficient movement
                
                **Applications:**
                - Convoy management
                - Formation flying
                - Sequential processing
            """)
        
        elif info_algo == "Wolf Optimization":
            st.markdown("""
                **Key Features:**
                - Hierarchical pack structure
                - Encircling behavior
                - Coordinated hunting
                - Global optimization focus
                
                **Strengths:**
                - Strong convergence
                - Balanced exploration/exploitation
                - Effective for complex landscapes
                
                **Applications:**
                - Feature selection
                - Engineering optimization
                - Machine learning tuning
            """)

# Footer with copyright
st.markdown("""
    <div class="footer">
        <p>© 2025 University of Djillali Liabes Sidi Bel Abbes | Developed by CVE-180396</p>
        <p>Bio-Inspired Optimization Algorithms Research Project</p>
        <p><em>Advanced Multi-Agent Systems Laboratory</em></p>
    </div>
""", unsafe_allow_html=True)
