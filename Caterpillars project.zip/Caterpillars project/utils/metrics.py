import numpy as np
import pandas as pd
import json
from typing import Dict, List, Any, Tuple
from datetime import datetime

def calculate_performance_metrics(algorithm_data: Dict[str, Any]) -> Dict[str, Dict[str, float]]:
    """Calculate comprehensive performance metrics for all algorithms."""
    
    metrics = {}
    
    for algo_name, data in algorithm_data.items():
        agents = data.get('agents', [])
        best_fitness = data.get('best_fitness', float('inf'))
        iteration = data.get('iteration', 0)
        
        if not agents:
            continue
        
        # Basic performance metrics
        algo_metrics = {
            'energy_consumption': calculate_energy_consumption(agents, data),
            'success_rate': calculate_success_rate(agents, data),
            'velocity': calculate_average_velocity(agents),
            'time_to_target': calculate_time_to_target(best_fitness, iteration),
            'convergence': calculate_convergence_rate(best_fitness),
            'diversity': calculate_population_diversity(agents),
            'robustness': calculate_robustness(agents, data),
            'adaptability': calculate_adaptability(agents, data)
        }
        
        # Algorithm-specific metrics
        if 'ACO' in algo_name or 'Ant' in algo_name:
            algo_metrics.update(calculate_aco_metrics(agents, data))
        elif 'Caterpillar' in algo_name:
            algo_metrics.update(calculate_caterpillar_metrics(agents, data))
        elif 'Wolf' in algo_name:
            algo_metrics.update(calculate_wolf_metrics(agents, data))
        
        metrics[algo_name.split()[0]] = algo_metrics  # Use short name
    
    return metrics

def calculate_energy_consumption(agents: List[Dict], data: Dict) -> float:
    """Calculate total energy consumption of the algorithm."""
    if not agents:
        return 0.0
    
    # Energy from movement
    movement_energy = 0.0
    for agent in agents:
        velocity = agent.get('velocity', [0, 0])
        speed = np.linalg.norm(velocity)
        movement_energy += float(speed ** 2)  # Quadratic energy cost
    
    # Normalize by population size
    avg_movement_energy = movement_energy / len(agents)
    
    # Environmental penalties
    env_effects = data.get('environment_effects', {})
    environmental_penalty = (
        env_effects.get('wind_strength', 0) * 0.1 +
        env_effects.get('rain_intensity', 0) * 0.15 +
        env_effects.get('obstacle_density', 0) * 0.2 +
        env_effects.get('terrain_roughness', 0) * 0.05
    )
    
    # Communication/coordination energy (algorithm-specific)
    coordination_energy = 0.1  # Base coordination cost
    
    total_energy = avg_movement_energy + environmental_penalty + coordination_energy
    
    # Normalize to 0-1 range
    return float(min(total_energy / 10.0, 1.0))

def calculate_success_rate(agents: List[Dict], data: Dict) -> float:
    """Calculate the success rate of agents reaching their objectives."""
    if not agents:
        return 0.0
    
    successful_agents = 0
    target_threshold = 3.0  # Distance threshold for success
    
    # Get target position from environment
    env_effects = data.get('environment_effects', {})
    target_pos = env_effects.get('target_position', [50, 50])  # Default target
    
    for agent in agents:
        agent_pos = agent.get('position', [0, 0])
        distance_to_target = np.linalg.norm(
            np.array(agent_pos) - np.array(target_pos)
        )
        
        if distance_to_target <= target_threshold:
            successful_agents += 1
    
    return successful_agents / len(agents)

def calculate_average_velocity(agents: List[Dict]) -> float:
    """Calculate the average velocity of all agents."""
    if not agents:
        return 0.0
    
    velocities = []
    for agent in agents:
        velocity = agent.get('velocity', [0, 0])
        speed = np.linalg.norm(velocity)
        velocities.append(speed)
    
    avg_velocity = np.mean(velocities)
    
    # Normalize to 0-1 range (assuming max reasonable velocity is 5.0)
    return float(min(avg_velocity / 5.0, 1.0))

def calculate_time_to_target(best_fitness: float, iteration: int) -> float:
    """Calculate normalized time to reach target."""
    if best_fitness == float('inf'):
        return 1.0  # Worst case
    
    # Inverse relationship: lower fitness = better performance = lower time
    fitness_factor = best_fitness / 100.0  # Normalize fitness
    iteration_factor = iteration / 100.0   # Normalize iteration
    
    time_metric = (fitness_factor + iteration_factor) / 2.0
    
    return min(time_metric, 1.0)

def calculate_convergence_rate(best_fitness: float) -> float:
    """Calculate convergence rate based on current best fitness."""
    if best_fitness == float('inf'):
        return 0.0
    
    # Higher convergence for lower fitness values
    convergence = 1.0 / (1.0 + best_fitness / 10.0)
    
    return min(convergence, 1.0)

def calculate_population_diversity(agents: List[Dict]) -> float:
    """Calculate the diversity of agent positions."""
    if len(agents) < 2:
        return 0.0
    
    positions = [agent.get('position', [0, 0]) for agent in agents]
    
    # Calculate pairwise distances
    distances = []
    for i in range(len(positions)):
        for j in range(i + 1, len(positions)):
            dist = np.linalg.norm(
                np.array(positions[i]) - np.array(positions[j])
            )
            distances.append(dist)
    
    if not distances:
        return 0.0
    
    avg_distance = np.mean(distances)
    
    # Normalize diversity (assuming max reasonable distance is 100)
    return float(min(avg_distance / 100.0, 1.0))

def calculate_robustness(agents: List[Dict], data: Dict) -> float:
    """Calculate algorithm robustness to environmental changes."""
    if not agents:
        return 0.0
    
    # Base robustness from agent distribution
    diversity = calculate_population_diversity(agents)
    
    # Environmental adaptation factor
    env_effects = data.get('environment_effects', {})
    env_stress = (
        env_effects.get('wind_strength', 0) +
        env_effects.get('rain_intensity', 0) +
        env_effects.get('obstacle_density', 0) +
        env_effects.get('terrain_roughness', 0)
    )
    
    # Robustness decreases with environmental stress but increases with diversity
    robustness = diversity * (1.0 - env_stress / 4.0)
    
    return float(max(0.0, min(robustness, 1.0)))

def calculate_adaptability(agents: List[Dict], data: Dict) -> float:
    """Calculate algorithm adaptability to dynamic conditions."""
    if not agents:
        return 0.0
    
    # Measure based on velocity changes and position adjustments
    velocity_variance = 0.0
    velocities = [np.linalg.norm(agent.get('velocity', [0, 0])) for agent in agents]
    
    if len(velocities) > 1:
        velocity_variance = np.var(velocities)
    
    # Higher variance indicates more adaptive behavior
    adaptability = velocity_variance / (1.0 + velocity_variance)
    
    return float(min(adaptability, 1.0))

def calculate_aco_metrics(agents: List[Dict], data: Dict) -> Dict[str, float]:
    """Calculate ACO-specific performance metrics."""
    metrics = {}
    
    # Pheromone trail efficiency
    pheromone_efficiency = 0.5  # Default value
    if 'pheromone_matrix' in str(data):
        # This would need access to actual pheromone data
        pheromone_efficiency = 0.7
    
    # Stigmergic coordination effectiveness
    coordination_effectiveness = calculate_aco_coordination(agents)
    
    # Path optimization score
    path_optimization = calculate_path_optimization(agents)
    
    metrics.update({
        'pheromone_efficiency': pheromone_efficiency,
        'coordination_effectiveness': coordination_effectiveness,
        'path_optimization': path_optimization
    })
    
    return metrics

def calculate_aco_coordination(agents: List[Dict]) -> float:
    """Calculate ACO coordination effectiveness."""
    if len(agents) < 2:
        return 0.0
    
    # Measure how well agents coordinate through indirect communication
    positions = [agent.get('position', [0, 0]) for agent in agents]
    
    # Calculate clustering coefficient (how close agents are to each other)
    avg_distance_to_nearest = []
    
    for i, pos1 in enumerate(positions):
        distances = []
        for j, pos2 in enumerate(positions):
            if i != j:
                dist = np.linalg.norm(np.array(pos1) - np.array(pos2))
                distances.append(dist)
        
        if distances:
            avg_distance_to_nearest.append(min(distances))
    
    if avg_distance_to_nearest:
        coordination = 1.0 / (1.0 + np.mean(avg_distance_to_nearest) / 10.0)
        return float(min(coordination, 1.0))
    
    return 0.0

def calculate_path_optimization(agents: List[Dict]) -> float:
    """Calculate path optimization efficiency."""
    if not agents:
        return 0.0
    
    # Measure based on agent paths and target proximity
    optimization_scores = []
    
    for agent in agents:
        position = agent.get('position', [0, 0])
        fitness = agent.get('fitness', float('inf'))
        
        if fitness != float('inf'):
            # Better fitness indicates better path optimization
            score = 1.0 / (1.0 + fitness / 10.0)
            optimization_scores.append(score)
    
    if optimization_scores:
        return float(np.mean(optimization_scores))
    
    return 0.0

def calculate_caterpillar_metrics(agents: List[Dict], data: Dict) -> Dict[str, float]:
    """Calculate Caterpillar-specific performance metrics."""
    metrics = {}
    
    # Formation coherence
    formation_coherence = calculate_formation_coherence(agents)
    
    # Leader effectiveness
    leader_effectiveness = calculate_leader_effectiveness(agents)
    
    # Following accuracy
    following_accuracy = calculate_following_accuracy(agents)
    
    # Trail utilization
    trail_utilization = 0.6  # Default value
    
    metrics.update({
        'formation_coherence': formation_coherence,
        'leader_effectiveness': leader_effectiveness,
        'following_accuracy': following_accuracy,
        'trail_utilization': trail_utilization
    })
    
    return metrics

def calculate_formation_coherence(agents: List[Dict]) -> float:
    """Calculate how well caterpillars maintain formation."""
    if len(agents) < 2:
        return 1.0
    
    # Measure deviations from expected linear formation
    positions = [agent.get('position', [0, 0]) for agent in agents]
    
    if len(positions) < 3:
        return 1.0
    
    # Calculate linearity of formation
    deviations = []
    for i in range(1, len(positions) - 1):
        p1 = np.array(positions[i-1])
        p2 = np.array(positions[i])
        p3 = np.array(positions[i+1])
        
        # Calculate deviation from straight line
        line_vec = p3 - p1
        point_vec = p2 - p1
        
        if np.linalg.norm(line_vec) > 0:
            # Project point onto line and calculate perpendicular distance
            projection = np.dot(point_vec, line_vec) / np.dot(line_vec, line_vec)
            projected_point = p1 + projection * line_vec
            deviation = np.linalg.norm(p2 - projected_point)
            deviations.append(deviation)
    
    if deviations:
        avg_deviation = np.mean(deviations)
        coherence = 1.0 / (1.0 + avg_deviation)
        return float(min(coherence, 1.0))
    
    return 1.0

def calculate_leader_effectiveness(agents: List[Dict]) -> float:
    """Calculate effectiveness of the leader caterpillar."""
    leaders = [agent for agent in agents if agent.get('is_leader', False)]
    
    if not leaders:
        return 0.0
    
    leader = leaders[0]
    leader_fitness = leader.get('fitness', float('inf'))
    
    if leader_fitness == float('inf'):
        return 0.0
    
    # Lower fitness indicates better leadership
    effectiveness = 1.0 / (1.0 + leader_fitness / 10.0)
    
    return float(min(effectiveness, 1.0))

def calculate_following_accuracy(agents: List[Dict]) -> float:
    """Calculate how accurately followers maintain distance."""
    if len(agents) < 2:
        return 1.0
    
    following_errors = []
    desired_distance = 1.0  # Default following distance
    
    for i in range(1, len(agents)):
        current_pos = np.array(agents[i].get('position', [0, 0]))
        leader_pos = np.array(agents[i-1].get('position', [0, 0]))
        
        actual_distance = np.linalg.norm(current_pos - leader_pos)
        error = abs(actual_distance - desired_distance)
        following_errors.append(error)
    
    if following_errors:
        avg_error = np.mean(following_errors)
        accuracy = 1.0 / (1.0 + avg_error)
        return float(min(accuracy, 1.0))
    
    return 1.0

def calculate_wolf_metrics(agents: List[Dict], data: Dict) -> Dict[str, float]:
    """Calculate Wolf-specific performance metrics."""
    metrics = {}
    
    # Pack cohesion
    pack_cohesion = calculate_pack_cohesion(agents)
    
    # Hierarchy effectiveness
    hierarchy_effectiveness = calculate_hierarchy_effectiveness(agents)
    
    # Hunting coordination
    hunting_coordination = calculate_hunting_coordination(agents)
    
    # Encircling efficiency
    encircling_efficiency = calculate_encircling_efficiency(agents)
    
    metrics.update({
        'pack_cohesion': pack_cohesion,
        'hierarchy_effectiveness': hierarchy_effectiveness,
        'hunting_coordination': hunting_coordination,
        'encircling_efficiency': encircling_efficiency
    })
    
    return metrics

def calculate_pack_cohesion(agents: List[Dict]) -> float:
    """Calculate pack cohesion for wolf algorithm."""
    if len(agents) < 2:
        return 1.0
    
    positions = [agent.get('position', [0, 0]) for agent in agents]
    center = np.mean(positions, axis=0)
    
    distances_to_center = [
        np.linalg.norm(np.array(pos) - center) for pos in positions
    ]
    
    avg_distance = np.mean(distances_to_center)
    cohesion = 1.0 / (1.0 + avg_distance / 20.0)
    
    return float(min(cohesion, 1.0))

def calculate_hierarchy_effectiveness(agents: List[Dict]) -> float:
    """Calculate effectiveness of wolf hierarchy."""
    alpha_wolves = [agent for agent in agents if agent.get('rank') == 'alpha']
    beta_wolves = [agent for agent in agents if agent.get('rank') == 'beta']
    delta_wolves = [agent for agent in agents if agent.get('rank') == 'delta']
    
    if not alpha_wolves:
        return 0.0
    
    alpha_fitness = alpha_wolves[0].get('fitness', float('inf'))
    
    # Check if hierarchy is properly maintained (alpha should have best fitness)
    other_wolves = [agent for agent in agents if agent.get('rank') != 'alpha']
    hierarchy_maintained = True
    
    for wolf in other_wolves:
        if wolf.get('fitness', float('inf')) < alpha_fitness:
            hierarchy_maintained = False
            break
    
    base_effectiveness = 1.0 if hierarchy_maintained else 0.5
    
    # Adjust based on alpha performance
    if alpha_fitness != float('inf'):
        performance_factor = 1.0 / (1.0 + alpha_fitness / 10.0)
        effectiveness = base_effectiveness * performance_factor
    else:
        effectiveness = 0.0
    
    return float(min(effectiveness, 1.0))

def calculate_hunting_coordination(agents: List[Dict]) -> float:
    """Calculate hunting coordination effectiveness."""
    if len(agents) < 3:
        return 0.0
    
    # Measure how well wolves coordinate their positions relative to target
    positions = [agent.get('position', [0, 0]) for agent in agents]
    
    # Calculate spread around target area
    center = np.mean(positions, axis=0)
    spread = np.std([np.linalg.norm(np.array(pos) - center) for pos in positions])
    
    # Good coordination has moderate spread (not too clustered, not too dispersed)
    optimal_spread = 5.0
    spread_score = 1.0 - abs(spread - optimal_spread) / optimal_spread
    
    return float(max(0.0, min(spread_score, 1.0)))

def calculate_encircling_efficiency(agents: List[Dict]) -> float:
    """Calculate efficiency of encircling behavior."""
    if len(agents) < 4:
        return 0.0
    
    positions = [np.array(agent.get('position', [0, 0])) for agent in agents]
    
    # Calculate if agents form a rough circle around center
    center = np.mean(positions, axis=0)
    distances = [np.linalg.norm(pos - center) for pos in positions]
    
    # Good encircling has similar distances from center
    distance_variance = np.var(distances)
    efficiency = 1.0 / (1.0 + distance_variance)
    
    return float(min(efficiency, 1.0))

def export_results(results_history: List[Dict], export_format: str = 'csv') -> str:
    """Export simulation results to specified format."""
    
    if not results_history:
        return ""
    
    if export_format.lower() == 'csv':
        return export_to_csv(results_history)
    elif export_format.lower() == 'json':
        return export_to_json(results_history)
    else:
        raise ValueError(f"Unsupported export format: {export_format}")

def export_to_csv(results_history: List[Dict]) -> str:
    """Export results to CSV format."""
    
    # Flatten the nested data structure
    rows = []
    
    for result in results_history:
        timestamp = result.get('timestamp', datetime.now())
        iteration = result.get('iteration', 0)
        
        for algo_name, metrics in result.items():
            if algo_name in ['timestamp', 'iteration']:
                continue
            
            row = {
                'timestamp': timestamp,
                'iteration': iteration,
                'algorithm': algo_name,
            }
            
            # Add all metrics
            if isinstance(metrics, dict):
                row.update(metrics)
            
            rows.append(row)
    
    if not rows:
        return ""
    
    df = pd.DataFrame(rows)
    return df.to_csv(index=False)

def export_to_json(results_history: List[Dict]) -> str:
    """Export results to JSON format."""
    
    # Convert datetime objects to strings
    json_data = []
    
    for result in results_history:
        json_result = {}
        for key, value in result.items():
            if isinstance(value, datetime):
                json_result[key] = value.isoformat()
            else:
                json_result[key] = value
        json_data.append(json_result)
    
    return json.dumps(json_data, indent=2, default=str)

def calculate_comparative_statistics(results_history: List[Dict]) -> Dict[str, Any]:
    """Calculate comparative statistics across algorithms."""
    
    if not results_history:
        return {}
    
    # Aggregate data by algorithm
    algorithm_data = {}
    
    for result in results_history:
        for algo_name, metrics in result.items():
            if algo_name in ['timestamp', 'iteration']:
                continue
            
            if algo_name not in algorithm_data:
                algorithm_data[algo_name] = {
                    'energy_consumption': [],
                    'success_rate': [],
                    'velocity': [],
                    'convergence': []
                }
            
            if isinstance(metrics, dict):
                for metric_name in algorithm_data[algo_name].keys():
                    if metric_name in metrics:
                        algorithm_data[algo_name][metric_name].append(metrics[metric_name])
    
    # Calculate statistics
    statistics = {}
    
    for algo_name, data in algorithm_data.items():
        algo_stats = {}
        
        for metric_name, values in data.items():
            if values:
                algo_stats[metric_name] = {
                    'mean': np.mean(values),
                    'std': np.std(values),
                    'min': np.min(values),
                    'max': np.max(values),
                    'median': np.median(values)
                }
        
        statistics[algo_name] = algo_stats
    
    return statistics
