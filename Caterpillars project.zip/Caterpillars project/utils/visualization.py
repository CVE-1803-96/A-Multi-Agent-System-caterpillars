import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import numpy as np
import pandas as pd
from typing import Dict, List, Any

def create_movement_plot(algorithm_data: Dict[str, Any], environment, iteration: int) -> go.Figure:
    """Create a visualization of agent movements for all algorithms."""
    
    # Create subplots for each algorithm
    num_algorithms = len(algorithm_data)
    if num_algorithms == 0:
        return go.Figure()
    
    cols = min(3, num_algorithms)
    rows = (num_algorithms + cols - 1) // cols
    
    subplot_titles = list(algorithm_data.keys())
    fig = make_subplots(
        rows=rows, cols=cols,
        subplot_titles=subplot_titles,
        specs=[[{'type': 'scatter'}] * cols for _ in range(rows)]
    )
    
    colors = ['blue', 'red', 'green', 'orange', 'purple', 'brown']
    
    for idx, (algo_name, data) in enumerate(algorithm_data.items()):
        row = (idx // cols) + 1
        col = (idx % cols) + 1
        color = colors[idx % len(colors)]
        
        agents = data.get('agents', [])
        
        # Plot agents
        if agents:
            agent_x = [agent['position'][0] for agent in agents]
            agent_y = [agent['position'][1] for agent in agents]
            
            # Different markers for different algorithms
            if 'ACO' in algo_name or 'Ant' in algo_name:
                marker_symbol = 'circle'
                marker_size = 6
            elif 'Caterpillar' in algo_name:
                marker_symbol = 'square'
                marker_size = 8
            elif 'Wolf' in algo_name:
                marker_symbol = 'diamond'
                marker_size = 10
            else:
                marker_symbol = 'circle'
                marker_size = 6
            
            fig.add_trace(
                go.Scatter(
                    x=agent_x, y=agent_y,
                    mode='markers',
                    marker=dict(
                        color=color,
                        symbol=marker_symbol,
                        size=marker_size,
                        opacity=0.7
                    ),
                    name=f'{algo_name} Agents',
                    showlegend=(idx == 0)
                ),
                row=row, col=col
            )
            
            # Add velocity vectors for better visualization
            for agent in agents[:10]:  # Show only first 10 for clarity
                pos = agent['position']
                vel = agent.get('velocity', [0, 0])
                
                if np.linalg.norm(vel) > 0.1:  # Only show significant velocities
                    fig.add_trace(
                        go.Scatter(
                            x=[pos[0], pos[0] + vel[0] * 2],
                            y=[pos[1], pos[1] + vel[1] * 2],
                            mode='lines',
                            line=dict(color=color, width=2, dash='dash'),
                            name='Velocity',
                            showlegend=False
                        ),
                        row=row, col=col
                    )
        
        # Plot target
        target_pos = environment.target_position
        fig.add_trace(
            go.Scatter(
                x=[target_pos[0]], y=[target_pos[1]],
                mode='markers',
                marker=dict(
                    symbol='star',
                    size=15,
                    color='gold',
                    line=dict(color='black', width=2)
                ),
                name='Target',
                showlegend=(idx == 0)
            ),
            row=row, col=col
        )
        
        # Plot obstacles
        for obstacle in environment.obstacles:
            obs_pos = obstacle['position']
            radius = obstacle['radius']
            
            # Create circle for obstacle
            theta = np.linspace(0, 2*np.pi, 50)
            obs_x = obs_pos[0] + radius * np.cos(theta)
            obs_y = obs_pos[1] + radius * np.sin(theta)
            
            fig.add_trace(
                go.Scatter(
                    x=obs_x, y=obs_y,
                    mode='lines',
                    fill='toself',
                    fillcolor='rgba(255,0,0,0.3)',
                    line=dict(color='red', width=2),
                    name='Obstacle',
                    showlegend=False
                ),
                row=row, col=col
            )
        
        # Add algorithm-specific visualizations
        if 'ACO' in algo_name and hasattr(data, 'get') and 'pheromone_matrix' in str(data):
            # Add pheromone trails for ACO
            add_pheromone_visualization(fig, data, environment, row, col)
        
        elif 'Caterpillar' in algo_name:
            # Add formation lines for caterpillars
            add_formation_visualization(fig, agents, row, col, color)
        
        elif 'Wolf' in algo_name:
            # Add pack hierarchy visualization
            add_pack_visualization(fig, agents, data, row, col, color)
        
        # Set axis properties
        fig.update_xaxes(
            range=[0, environment.width],
            title_text="X Position" if row == rows else "",
            row=row, col=col
        )
        fig.update_yaxes(
            range=[0, environment.height],
            title_text="Y Position" if col == 1 else "",
            row=row, col=col
        )
    
    # Update layout
    fig.update_layout(
        title=f"Bio-Inspired Algorithms Comparison - Iteration {iteration}",
        height=400 * rows,
        showlegend=True,
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    return fig

def add_pheromone_visualization(fig, data, environment, row, col):
    """Add pheromone trail visualization for ACO."""
    # This would require access to the pheromone matrix from the ACO algorithm
    # For now, we'll add a simple trail representation
    pass

def add_formation_visualization(fig, agents, row, col, color):
    """Add formation lines for caterpillar algorithm."""
    if len(agents) > 1:
        # Connect caterpillars in order
        x_coords = [agent['position'][0] for agent in agents]
        y_coords = [agent['position'][1] for agent in agents]
        
        fig.add_trace(
            go.Scatter(
                x=x_coords, y=y_coords,
                mode='lines',
                line=dict(color=color, width=2, dash='dot'),
                name='Formation Line',
                showlegend=False
            ),
            row=row, col=col
        )

def add_pack_visualization(fig, agents, data, row, col, color):
    """Add pack hierarchy visualization for wolf algorithm."""
    # Highlight alpha, beta, delta wolves
    alpha_agents = [agent for agent in agents if agent.get('rank') == 'alpha']
    beta_agents = [agent for agent in agents if agent.get('rank') == 'beta']
    delta_agents = [agent for agent in agents if agent.get('rank') == 'delta']
    
    # Add larger markers for hierarchy
    for agent_group, rank_color, rank_name in [
        (alpha_agents, 'gold', 'Alpha'),
        (beta_agents, 'silver', 'Beta'),
        (delta_agents, 'orange', 'Delta')
    ]:
        if agent_group:
            x_coords = [agent['position'][0] for agent in agent_group]
            y_coords = [agent['position'][1] for agent in agent_group]
            
            fig.add_trace(
                go.Scatter(
                    x=x_coords, y=y_coords,
                    mode='markers',
                    marker=dict(
                        symbol='circle-open',
                        size=15,
                        color=rank_color,
                        line=dict(width=3)
                    ),
                    name=f'{rank_name} Wolf',
                    showlegend=False
                ),
                row=row, col=col
            )

def create_pheromone_plot(pheromone_data, environment) -> go.Figure:
    """Create a heatmap visualization of pheromone trails."""
    fig = go.Figure()
    
    if pheromone_data is not None:
        fig.add_trace(
            go.Heatmap(
                z=pheromone_data,
                colorscale='Viridis',
                showscale=True,
                colorbar=dict(title="Pheromone Intensity")
            )
        )
    
    fig.update_layout(
        title="Pheromone Trail Intensity",
        xaxis_title="Grid X",
        yaxis_title="Grid Y"
    )
    
    return fig

def create_performance_comparison(metrics_history: List[Dict]) -> go.Figure:
    """Create performance comparison charts."""
    if not metrics_history:
        return go.Figure()
    
    # Convert to DataFrame for easier handling
    df_data = []
    for entry in metrics_history:
        for algo, metrics in entry.items():
            if algo not in ['iteration', 'timestamp']:
                row = {
                    'iteration': entry['iteration'],
                    'algorithm': algo,
                    **metrics
                }
                df_data.append(row)
    
    df = pd.DataFrame(df_data)
    
    if df.empty:
        return go.Figure()
    
    # Create subplots for different metrics
    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=['Energy Consumption', 'Success Rate', 'Velocity', 'Convergence'],
        specs=[[{'type': 'scatter'}, {'type': 'scatter'}],
               [{'type': 'scatter'}, {'type': 'scatter'}]]
    )
    
    algorithms = df['algorithm'].unique()
    colors = px.colors.qualitative.Set1[:len(algorithms)]
    
    metrics = ['energy_consumption', 'success_rate', 'velocity', 'convergence']
    positions = [(1,1), (1,2), (2,1), (2,2)]
    
    for i, metric in enumerate(metrics):
        row, col = positions[i]
        
        for j, algo in enumerate(algorithms):
            algo_data = df[df['algorithm'] == algo]
            
            fig.add_trace(
                go.Scatter(
                    x=algo_data['iteration'],
                    y=algo_data[metric],
                    mode='lines+markers',
                    name=algo,
                    line=dict(color=colors[j]),
                    showlegend=(i == 0)  # Only show legend for first subplot
                ),
                row=row, col=col
            )
    
    fig.update_layout(
        title="Algorithm Performance Comparison Over Time",
        height=600,
        showlegend=True
    )
    
    return fig

def create_environmental_impact_plot(metrics_data: Dict, environmental_params: Dict) -> go.Figure:
    """Create visualization showing environmental impact on algorithms."""
    
    # Create radar chart showing environmental sensitivity
    categories = ['Wind Resistance', 'Rain Adaptation', 'Obstacle Avoidance', 'Terrain Navigation']
    
    fig = go.Figure()
    
    for algo_name, metrics in metrics_data.items():
        # Calculate environmental adaptation scores
        wind_resistance = 1 - (environmental_params['wind_strength'] * 0.5)
        rain_adaptation = 1 - (environmental_params['rain_intensity'] * 0.4)
        obstacle_avoidance = 1 - (environmental_params['obstacle_density'] * 0.8)
        terrain_navigation = 1 - (environmental_params['terrain_roughness'] * 0.3)
        
        values = [wind_resistance, rain_adaptation, obstacle_avoidance, terrain_navigation]
        
        fig.add_trace(go.Scatterpolar(
            r=values,
            theta=categories,
            fill='toself',
            name=algo_name,
            line=dict(width=2)
        ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 1]
            )),
        showlegend=True,
        title="Environmental Adaptation Capabilities"
    )
    
    return fig

def create_algorithm_comparison_table(latest_metrics: Dict) -> go.Figure:
    """Create a comparison table of algorithm performance."""
    
    if not latest_metrics:
        return go.Figure()
    
    # Prepare data for table
    algorithms = []
    energy_scores = []
    success_rates = []
    velocities = []
    overall_scores = []
    
    for algo_name, metrics in latest_metrics.items():
        algorithms.append(algo_name)
        energy_scores.append(f"{metrics.get('energy_consumption', 0):.3f}")
        success_rates.append(f"{metrics.get('success_rate', 0):.3f}")
        velocities.append(f"{metrics.get('velocity', 0):.3f}")
        
        # Calculate overall score
        overall_score = (
            metrics.get('success_rate', 0) * 0.4 +
            (1 - metrics.get('energy_consumption', 1)) * 0.3 +
            metrics.get('velocity', 0) * 0.2 +
            metrics.get('convergence', 0) * 0.1
        )
        overall_scores.append(f"{overall_score:.3f}")
    
    fig = go.Figure(data=[go.Table(
        header=dict(
            values=['Algorithm', 'Energy Efficiency', 'Success Rate', 'Velocity', 'Overall Score'],
            fill_color='paleturquoise',
            align='left',
            font=dict(size=12, color='black')
        ),
        cells=dict(
            values=[algorithms, energy_scores, success_rates, velocities, overall_scores],
            fill_color='lavender',
            align='left',
            font=dict(size=11, color='black')
        )
    )])
    
    fig.update_layout(
        title="Algorithm Performance Summary",
        height=300
    )
    
    return fig
