import numpy as np
import random
from typing import List, Dict, Tuple, Any

class Environment:
    """Environment class for managing simulation conditions and obstacles."""
    
    def __init__(self, width: float = 100.0, height: float = 100.0, 
                 wind_strength: float = 0.0, rain_intensity: float = 0.0,
                 obstacle_density: float = 0.0, terrain_roughness: float = 0.0):
        
        self.width = width
        self.height = height
        self.wind_strength = wind_strength
        self.rain_intensity = rain_intensity
        self.obstacle_density = obstacle_density
        self.terrain_roughness = terrain_roughness
        
        # Target position (goal for all algorithms)
        self.target_position = [width * 0.9, height * 0.5]
        
        # Generate obstacles based on density
        self.obstacles = self.generate_obstacles()
        
        # Environmental zones with different properties
        self.zones = self.generate_environmental_zones()
        
        # Wind direction (changes over time)
        self.wind_direction = random.uniform(0, 2 * np.pi)
        self.wind_change_rate = 0.05
        
        # Time-varying environmental effects
        self.time_step = 0
        self.weather_cycle_length = 200  # Steps for weather cycle
        
    def generate_obstacles(self) -> List[Dict[str, Any]]:
        """Generate obstacles based on obstacle density."""
        obstacles = []
        
        # Calculate number of obstacles based on density
        max_obstacles = int((self.width * self.height) / 500)  # Base density
        num_obstacles = int(max_obstacles * self.obstacle_density)
        
        for i in range(num_obstacles):
            # Ensure obstacles don't block start or target areas
            while True:
                x = random.uniform(0, self.width)
                y = random.uniform(0, self.height)
                
                # Avoid start area (left 20% of environment)
                if x < self.width * 0.2:
                    continue
                
                # Avoid target area
                target_distance = np.linalg.norm([x - self.target_position[0], 
                                                y - self.target_position[1]])
                if target_distance < 8.0:
                    continue
                
                break
            
            obstacle = {
                'position': [x, y],
                'radius': random.uniform(2.0, 5.0),
                'type': random.choice(['static', 'dynamic']),
                'hardness': random.uniform(0.5, 1.0)  # Affects movement penalty
            }
            obstacles.append(obstacle)
        
        return obstacles
    
    def generate_environmental_zones(self) -> List[Dict[str, Any]]:
        """Generate environmental zones with different properties."""
        zones = []
        
        # Create some environmental zones based on terrain roughness
        if self.terrain_roughness > 0.3:
            num_zones = random.randint(2, 5)
            
            for i in range(num_zones):
                zone = {
                    'center': [random.uniform(0, self.width), 
                              random.uniform(0, self.height)],
                    'radius': random.uniform(10.0, 20.0),
                    'type': random.choice(['rough', 'smooth', 'muddy', 'rocky']),
                    'movement_modifier': random.uniform(0.5, 1.5),
                    'visibility_modifier': random.uniform(0.7, 1.0)
                }
                zones.append(zone)
        
        return zones
    
    def update_environment(self):
        """Update dynamic environmental conditions."""
        self.time_step += 1
        
        # Update wind direction
        self.wind_direction += random.uniform(-self.wind_change_rate, self.wind_change_rate)
        self.wind_direction = self.wind_direction % (2 * np.pi)
        
        # Weather cycle effects
        cycle_position = (self.time_step % self.weather_cycle_length) / self.weather_cycle_length
        
        # Sinusoidal variation in weather intensity
        weather_intensity = 0.5 + 0.5 * np.sin(2 * np.pi * cycle_position)
        
        # Apply weather cycle to rain intensity
        base_rain = self.rain_intensity
        self.rain_intensity = base_rain * weather_intensity
        
        # Update dynamic obstacles
        for obstacle in self.obstacles:
            if obstacle['type'] == 'dynamic':
                # Move obstacle slightly
                angle = random.uniform(0, 2 * np.pi)
                speed = 0.5
                dx = speed * np.cos(angle)
                dy = speed * np.sin(angle)
                
                # Update position with bounds checking
                new_x = obstacle['position'][0] + dx
                new_y = obstacle['position'][1] + dy
                
                obstacle['position'][0] = np.clip(new_x, obstacle['radius'], 
                                                self.width - obstacle['radius'])
                obstacle['position'][1] = np.clip(new_y, obstacle['radius'], 
                                                self.height - obstacle['radius'])
    
    def get_wind_effect(self, position: List[float]) -> np.ndarray:
        """Get wind effect at a specific position."""
        if self.wind_strength <= 0:
            return np.array([0.0, 0.0])
        
        # Wind effect varies with position (turbulence)
        x, y = position
        
        # Base wind direction
        base_wind = np.array([np.cos(self.wind_direction), 
                             np.sin(self.wind_direction)])
        
        # Add turbulence based on position
        turbulence_factor = 0.3
        turbulence = np.array([
            np.sin(x * 0.1) * turbulence_factor,
            np.cos(y * 0.1) * turbulence_factor
        ])
        
        # Combine base wind with turbulence
        wind_vector = base_wind * self.wind_strength + turbulence
        
        return wind_vector
    
    def get_terrain_effect(self, position: List[float]) -> float:
        """Get terrain effect at a specific position."""
        if self.terrain_roughness <= 0:
            return 1.0
        
        x, y = position
        
        # Create terrain variation using noise-like function
        terrain_noise = (np.sin(x * 0.05) * np.cos(y * 0.05) + 
                        np.sin(x * 0.1 + 1.5) * np.cos(y * 0.1 + 1.5)) / 2.0
        
        # Convert to movement modifier
        roughness_effect = 1.0 - (self.terrain_roughness * 0.3 * (1 + terrain_noise))
        
        return max(0.2, roughness_effect)  # Minimum 20% movement speed
    
    def get_visibility(self, position: List[float]) -> float:
        """Get visibility factor at a specific position (affected by rain)."""
        base_visibility = 1.0
        
        # Rain reduces visibility
        rain_effect = 1.0 - (self.rain_intensity * 0.4)
        
        # Check if position is in any environmental zone
        zone_effect = 1.0
        for zone in self.zones:
            distance = np.linalg.norm(np.array(position) - np.array(zone['center']))
            if distance <= zone['radius']:
                zone_effect = zone['visibility_modifier']
                break
        
        return base_visibility * rain_effect * zone_effect
    
    def check_collision(self, position: List[float], radius: float = 1.0) -> bool:
        """Check if a position collides with any obstacle."""
        pos_array = np.array(position)
        
        for obstacle in self.obstacles:
            obstacle_pos = np.array(obstacle['position'])
            distance = np.linalg.norm(pos_array - obstacle_pos)
            
            if distance < (obstacle['radius'] + radius):
                return True
        
        return False
    
    def get_closest_obstacle(self, position: List[float]):
        """Get the closest obstacle to a given position."""
        if not self.obstacles:
            return None
        
        pos_array = np.array(position)
        min_distance = float('inf')
        closest_obstacle = None
        
        for obstacle in self.obstacles:
            obstacle_pos = np.array(obstacle['position'])
            distance = np.linalg.norm(pos_array - obstacle_pos)
            
            if distance < min_distance:
                min_distance = distance
                closest_obstacle = obstacle.copy()
                closest_obstacle['distance'] = distance
        
        return closest_obstacle
    
    def get_path_to_target(self, start_position: List[float]) -> List[List[float]]:
        """Get a simple path from start position to target avoiding obstacles."""
        path = [start_position]
        current_pos = np.array(start_position)
        target_pos = np.array(self.target_position)
        
        max_steps = 50
        step_size = 2.0
        
        for step in range(max_steps):
            # Direction to target
            direction = target_pos - current_pos
            distance_to_target = np.linalg.norm(direction)
            
            if distance_to_target < step_size:
                path.append(self.target_position)
                break
            
            direction = direction / distance_to_target
            
            # Check for obstacles in the way
            next_pos = current_pos + direction * step_size
            
            # Simple obstacle avoidance
            if self.check_collision(next_pos.tolist(), 1.0):
                # Try to go around obstacle
                perpendicular = np.array([-direction[1], direction[0]])
                
                # Try both sides
                for side in [1, -1]:
                    avoidance_pos = current_pos + perpendicular * side * step_size
                    if not self.check_collision(avoidance_pos.tolist(), 1.0):
                        next_pos = avoidance_pos
                        break
            
            # Keep within bounds
            next_pos[0] = np.clip(next_pos[0], 0, self.width)
            next_pos[1] = np.clip(next_pos[1], 0, self.height)
            
            current_pos = next_pos
            path.append(current_pos.tolist())
        
        return path
    
    def get_current_effects(self) -> Dict[str, Any]:
        """Get current environmental effects summary."""
        return {
            'wind_strength': self.wind_strength,
            'wind_direction': self.wind_direction,
            'rain_intensity': self.rain_intensity,
            'obstacle_density': self.obstacle_density,
            'terrain_roughness': self.terrain_roughness,
            'target_position': self.target_position,
            'time_step': self.time_step,
            'num_obstacles': len(self.obstacles),
            'num_zones': len(self.zones)
        }
    
    def reset_environment(self):
        """Reset environment to initial state."""
        self.time_step = 0
        self.wind_direction = random.uniform(0, 2 * np.pi)
        self.obstacles = self.generate_obstacles()
        self.zones = self.generate_environmental_zones()
    
    def get_environmental_stress(self, position: List[float]) -> float:
        """Calculate total environmental stress at a position."""
        wind_effect = np.linalg.norm(self.get_wind_effect(position))
        terrain_effect = 1.0 - self.get_terrain_effect(position)
        visibility_effect = 1.0 - self.get_visibility(position)
        
        # Check proximity to obstacles
        obstacle_stress = 0.0
        closest_obstacle = self.get_closest_obstacle(position)
        if closest_obstacle and closest_obstacle['distance'] < 10.0:
            obstacle_stress = 1.0 - (closest_obstacle['distance'] / 10.0)
        
        total_stress = (wind_effect * 0.2 + 
                       terrain_effect * 0.3 + 
                       visibility_effect * 0.2 + 
                       obstacle_stress * 0.3)
        
        return float(min(total_stress, 1.0))
    
    def is_valid_position(self, position: List[float]) -> bool:
        """Check if a position is valid (within bounds and not colliding)."""
        x, y = position
        
        # Check bounds
        if x < 0 or x > self.width or y < 0 or y > self.height:
            return False
        
        # Check collision with obstacles
        if self.check_collision(position):
            return False
        
        return True
    
    def get_safe_random_position(self) -> List[float]:
        """Get a random position that's safe (no collision)."""
        max_attempts = 100
        
        for attempt in range(max_attempts):
            x = random.uniform(0, self.width)
            y = random.uniform(0, self.height)
            position = [x, y]
            
            if self.is_valid_position(position):
                return position
        
        # If no safe position found, return a default position
        return [self.width * 0.1, self.height * 0.5]
    
    def export_environment_data(self) -> Dict[str, Any]:
        """Export environment data for analysis."""
        return {
            'dimensions': {'width': self.width, 'height': self.height},
            'conditions': {
                'wind_strength': self.wind_strength,
                'wind_direction': self.wind_direction,
                'rain_intensity': self.rain_intensity,
                'obstacle_density': self.obstacle_density,
                'terrain_roughness': self.terrain_roughness
            },
            'target_position': self.target_position,
            'obstacles': self.obstacles,
            'zones': self.zones,
            'time_step': self.time_step
        }
